from threading import Thread, current_thread
from time import sleep

#class Thread(group = None,
#             target = None,
#             name = None,
#             arg = (),
#             kwargs = {})

def primeira_funcao():
    print(current_thread().name + str(' Estamos iniciando \n'))

    sleep(5)
    print(current_thread().name + str(' Estamos iniciando \n'))
    return

def segunda_funcao():
    print(current_thread().name + str(' Estamos iniciando \n'))

    sleep(2)
    print(current_thread().name + str(' Estamos iniciando \n'))
    return

def terceira_funcao():
    print(current_thread().name + str(' Estamos iniciando \n'))

    sleep(10)
    print(current_thread().name + str(' Estamos iniciando \n'))
    return

if __name__ == '__main__':
    t1 = Thread(name='Primeira Funcao', target=primeira_funcao)
    t2 = Thread(name='SegundaFuncao', target=segunda_funcao)
    t3 = Thread(name='Terceira Funcao', target=terceira_funcao)

    t1.start()
    t2.start()
    t3.start()