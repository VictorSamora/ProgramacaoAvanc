from threading import Thread
import time

class MyThread(Thread):
    def __init__(self, name, delay): 
        Thread.__init__(self)
        self.name = name
        self.delay = delay
    
    def thread_count_down(self, name, delay):
        counter = 10
        while counter:
            time.sleep(delay)
            print('Thread %s counting down: %i...' % (name, counter))
            counter -= 1
    
    def run(self):
        print('Starting Thread %s.' % self.name)
        self.thread_count_down(self.name, self.delay)
        print('Finished thread %s.' % self.name)