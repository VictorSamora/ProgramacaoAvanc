import os
from flask import Flask, render_template
from ext import db as ext_db
from ext.cli import custom_shell_command
from flask_moment import Moment

moment = Moment()

# Shell context para flask shell
def make_shell_context():
        from ext.db import db
        from core.models import User, Role  # adicione outros modelos conforme necessário
        return dict(db=db, User=User, Role=Role)

def create_app(config_name='development'):
    # Caminho base do projeto
    base_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

    # Criacao da instancia Flask
    app = Flask(
        __name__,
        static_folder=os.path.join(base_dir, 'static'),
        template_folder=os.path.join(base_dir, 'templates')
    )

    # Carregamento da configuracao conforme o ambiente
    if config_name == 'development':
        app.config.from_object('config.DevelopmentConfig')
    elif config_name == 'production':
        app.config.from_object('config.ProductionConfig')
    else:
        app.config.from_object('config.DefaultConfig')

    # Inicializacao das extensoes
    ext_db.init_app(app)
    moment.init_app(app)

    # Registro dos comandos customizados
    app.cli.add_command(custom_shell_command)

    # Importacao dos modelos (obrigatoria para db.create_all())
    from core import models

    # Variavel de ambiente disponivel nas rotas
    app.config["CONFIG_NAME"] = config_name
    
    # Registro dos blueprints
    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    # Handlers de erro
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    # Registro do processor
    app.shell_context_processor(make_shell_context)
    
    return app