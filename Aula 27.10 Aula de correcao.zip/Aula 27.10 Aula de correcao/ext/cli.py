import click
from flask.cli import with_appcontext

@click.command("ipyshell")
@with_appcontext
def custom_shell_command():
    """Abre um shell interativo com IPython (ou REPL padrão se indisponível)."""
    import code
    from views import make_shell_context

    context = make_shell_context()

    try:
        from IPython import start_ipython
        from traitlets.config import Config

        cfg = Config()
        cfg.TerminalInteractiveShell.banner1 = "Iniciando IPython com contexto Flask..."
        start_ipython(argv=[], user_ns=context, config=cfg)
    except ImportError:
        banner = "Iniciando shell padrão do Python com contexto Flask..."
        code.interact(banner=banner, local=context)
