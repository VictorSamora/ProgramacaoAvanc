import os
from flask import Flask, render_template
from flask_moment import Moment
from ext import db

ext_db = db()

moment = Moment()

def create_app(config_name='development'):
    # Define o caminho base do projeto
    base_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

    app = Flask(
        __name__,
        static_folder=os.path.join(base_dir, 'static'),
        template_folder=os.path.join(base_dir, 'templates')
    )

    if config_name == 'development':
        app.config.from_object('config.DevelopmentConfig')
    elif config_name == 'production':
        app.config.from_object('config.ProductionConfig')
    else:
        app.config.from_object('config.DefaultConfig')

    # Inicialização do DB


    # Adiciona a variável customizada para uso em rotas
    app.config["CONFIG_NAME"] = config_name
    
    # Inicializa o Moment com a app
    moment.init_app(app)

    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    return app
