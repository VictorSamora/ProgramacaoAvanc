import requests
import threading
import time

def ping(url):
    res = requests.get(url)
    print(f'{url} : {res.text}')

urls = {
    'https://tools-httpstatus.pickup-services.com/100',
    'https://tools-httpstatus.pickup-services.com/200',
    'https://tools-httpstatus.pickup-services.com/400',
    'https://tools-httpstatus.pickup-services.com/404',
    'https://tools-httpstatus.pickup-services.com/418',
    'https://tools-httpstatus.pickup-services.com/500',
    'https://tools-httpstatus.pickup-services.com/524',
    'https://tools-httpstatus.pickup-services.com/317'
}

start = time.time()

for url in urls:
    ping(url)
print (f'Sequential: {time.time() - start: .2f} seconds')
print()

start = time.time()
threads = []

for url in urls:
    thread = threading.Thread(target=ping, args=(urls,))
    threads.append(thread)
    thread.start()

for thread in threads:
    thread.join()

print(f'Threading: {time.time() - start: .2f} seconds')
