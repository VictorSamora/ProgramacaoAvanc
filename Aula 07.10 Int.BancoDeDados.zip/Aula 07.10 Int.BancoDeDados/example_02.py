import requests

def ping(url):
    res = requests.get(url)
    print(f'{url} : {res.text}')

urls = {
    'https://tools-httpstatus.pickup-services.com/100',
    'https://tools-httpstatus.pickup-services.com/200',
    'https://tools-httpstatus.pickup-services.com/400',
    'https://tools-httpstatus.pickup-services.com/404',
    'https://tools-httpstatus.pickup-services.com/418',
    'https://tools-httpstatus.pickup-services.com/500',
    'https://tools-httpstatus.pickup-services.com/524',
    'https://tools-httpstatus.pickup-services.com/317'
}

for url in urls:
    ping(url)

print('Done')