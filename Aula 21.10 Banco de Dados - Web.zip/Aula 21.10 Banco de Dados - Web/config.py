import os

basedir = os.path.abspath(os.path.dirname(__file__))

class DefaultConfig:
    DEBUG = False
    TESTING = False
    SECRET_KEY = os.environ.get('SECRET_KEY', 'nossa-chave-secreta-aqui')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'app.db')


class DevelopmentConfig(DefaultConfig):
    DEBUG = True
    TESTING = True
    ENV = 'development'


class ProductionConfig(DefaultConfig):
    ENV = 'production'
    # DEBUG e TESTING ja estao definidos como False na classe base
