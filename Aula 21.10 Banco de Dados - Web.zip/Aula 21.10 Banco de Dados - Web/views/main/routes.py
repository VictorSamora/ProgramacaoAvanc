from datetime import datetime
from flask import current_app, render_template, session, redirect, url_for, flash
from . import main
from ext.site.forms import NameForm
from ext.db import db
from core.models import User, Role

...

@main.route('/user', methods=['GET','POST'])
def user():
    form = NameForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.name.data).first()

        if user is None:
            # Busca o papel user no Banco de Dados
            role = Role.query.filter_by(name='User').first()

            # Criacao de um novo usuario com valores obrigatorios
            user = User(
                usename=form.name.data,
                password_hash='fake_hash', # Apenas para Testes
                role = role 
            )
            db.session.add(user)
            db.session.commit()
            session['known'] = False 
        else: 
            session['known'] = True
        session['name'] = form.name.data
        form.name.data = ''
        return redirect(url_for('main.user'))

    return render_template(
        'usuario.html',
        form=form,
        name=session.get('name'),
        know=session.get('known', False)
    )


@main.route('/index')
def index():
    ambiente = current_app.config.get("CONFIG_NAME", "desconhecido")
    user = {'username': 'Wanderson'}

    posts = [
        {'author': {'username': 'Joao'},
         'body': 'Belo dia em Vila Velha!'},
        {'author': {'username': 'Maria'},
         'body': 'Bora para o cinema hoje?'}
    ]

    # Passa current_time para o template para usar com Flask-Moment
    return render_template(
        'index.html',
        title='Home',
        user=user,
        posts=posts,
        current_time=datetime.utcnow()
    )


@main.route('/erro500')
def erro500():
    # Isso vai causar ZeroDivisionError (erro 500)
    1 / 0
    return "Isso nunca será exibido"
