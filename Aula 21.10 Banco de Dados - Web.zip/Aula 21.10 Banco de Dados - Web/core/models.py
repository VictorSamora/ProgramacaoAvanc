from typing import Optional, List
import sqlalchemy as sa
import sqlalchemy.orm as so
from ext.db import db

class Role(db.Model):
    __tablename__ = 'roles'
    __allow_unmapped__ = True

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    name: so.Mapped[str] = so.mapped_column(sa.String(64), unique=True)

    # Relacionamento: um papel tem muitos usuarios
    users: so.Mapped[List["User"]] = so.relationship("User", back_populates="role")

    def __repr__(self):
        return f"<Role {self.name}>"

class User(db.Model):
    __tablename__ = 'users'
    __allow_unmapped__ = True

    id: so.Mapped[int] = so.mapped_column(primary_key=True)
    username: so.Mapped[str] = so.mapped_column(sa.String(64), index=True, unique=True)
    password_hash: so.Mapped[Optional[str]] = so.mapped_column(sa.String(256))

    # Relacionamento: muitos usuarios tem um papel
    role_id: so.Mapped[int] = so.mapped_column(sa.ForeignKey("roles.id"))
    role: so.Mapped["Role"] = so.relationship(back_populates="users")

    def __repr__(self):
        return f"<User {self.username}>"